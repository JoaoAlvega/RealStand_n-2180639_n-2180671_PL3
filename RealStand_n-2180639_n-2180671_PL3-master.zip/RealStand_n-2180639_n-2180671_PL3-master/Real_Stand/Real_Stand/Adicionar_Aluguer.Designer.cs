﻿namespace Real_Stand
{
    partial class Adicionar_Aluguer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxDtaSaida3 = new System.Windows.Forms.TextBox();
            this.textBoxDtaSaida2 = new System.Windows.Forms.TextBox();
            this.textBoxDtaSaida1 = new System.Windows.Forms.TextBox();
            this.textBoxDtaInicio3 = new System.Windows.Forms.TextBox();
            this.textBoxDtaInicio2 = new System.Windows.Forms.TextBox();
            this.comboBoxEstado = new System.Windows.Forms.ComboBox();
            this.textBoxDtaInicio1 = new System.Windows.Forms.TextBox();
            this.labelDtaFim = new System.Windows.Forms.Label();
            this.labelDtaInicio = new System.Windows.Forms.Label();
            this.labelTipoServico = new System.Windows.Forms.Label();
            this.buttonGuardar = new System.Windows.Forms.Button();
            this.buttonVoltar = new System.Windows.Forms.Button();
            this.textBoxKms = new System.Windows.Forms.TextBox();
            this.labelKms = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(267, 199);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 13);
            this.label5.TabIndex = 145;
            this.label5.Text = "/";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(212, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 13);
            this.label4.TabIndex = 144;
            this.label4.Text = "/";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(267, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(12, 13);
            this.label3.TabIndex = 143;
            this.label3.Text = "/";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(210, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 13);
            this.label2.TabIndex = 142;
            this.label2.Text = "/";
            // 
            // textBoxDtaSaida3
            // 
            this.textBoxDtaSaida3.Location = new System.Drawing.Point(285, 196);
            this.textBoxDtaSaida3.Name = "textBoxDtaSaida3";
            this.textBoxDtaSaida3.Size = new System.Drawing.Size(33, 20);
            this.textBoxDtaSaida3.TabIndex = 141;
            this.textBoxDtaSaida3.Text = "ano";
            // 
            // textBoxDtaSaida2
            // 
            this.textBoxDtaSaida2.Location = new System.Drawing.Point(228, 196);
            this.textBoxDtaSaida2.Name = "textBoxDtaSaida2";
            this.textBoxDtaSaida2.Size = new System.Drawing.Size(33, 20);
            this.textBoxDtaSaida2.TabIndex = 140;
            this.textBoxDtaSaida2.Text = "mes";
            // 
            // textBoxDtaSaida1
            // 
            this.textBoxDtaSaida1.Location = new System.Drawing.Point(173, 196);
            this.textBoxDtaSaida1.Name = "textBoxDtaSaida1";
            this.textBoxDtaSaida1.Size = new System.Drawing.Size(33, 20);
            this.textBoxDtaSaida1.TabIndex = 139;
            this.textBoxDtaSaida1.Text = "dia";
            // 
            // textBoxDtaInicio3
            // 
            this.textBoxDtaInicio3.Location = new System.Drawing.Point(285, 170);
            this.textBoxDtaInicio3.Name = "textBoxDtaInicio3";
            this.textBoxDtaInicio3.Size = new System.Drawing.Size(33, 20);
            this.textBoxDtaInicio3.TabIndex = 138;
            this.textBoxDtaInicio3.Text = "ano";
            // 
            // textBoxDtaInicio2
            // 
            this.textBoxDtaInicio2.Location = new System.Drawing.Point(228, 170);
            this.textBoxDtaInicio2.Name = "textBoxDtaInicio2";
            this.textBoxDtaInicio2.Size = new System.Drawing.Size(33, 20);
            this.textBoxDtaInicio2.TabIndex = 137;
            this.textBoxDtaInicio2.Text = "mes";
            // 
            // comboBoxEstado
            // 
            this.comboBoxEstado.FormattingEnabled = true;
            this.comboBoxEstado.Items.AddRange(new object[] {
            "ALUGADO",
            "LIVRE",
            "TERMINADO"});
            this.comboBoxEstado.Location = new System.Drawing.Point(173, 143);
            this.comboBoxEstado.Name = "comboBoxEstado";
            this.comboBoxEstado.Size = new System.Drawing.Size(218, 21);
            this.comboBoxEstado.TabIndex = 136;
            // 
            // textBoxDtaInicio1
            // 
            this.textBoxDtaInicio1.Location = new System.Drawing.Point(173, 170);
            this.textBoxDtaInicio1.Name = "textBoxDtaInicio1";
            this.textBoxDtaInicio1.Size = new System.Drawing.Size(33, 20);
            this.textBoxDtaInicio1.TabIndex = 135;
            this.textBoxDtaInicio1.Text = "dia";
            // 
            // labelDtaFim
            // 
            this.labelDtaFim.AutoSize = true;
            this.labelDtaFim.Location = new System.Drawing.Point(102, 199);
            this.labelDtaFim.Name = "labelDtaFim";
            this.labelDtaFim.Size = new System.Drawing.Size(52, 13);
            this.labelDtaFim.TabIndex = 134;
            this.labelDtaFim.Text = "Data Fim:";
            // 
            // labelDtaInicio
            // 
            this.labelDtaInicio.AutoSize = true;
            this.labelDtaInicio.Location = new System.Drawing.Point(94, 173);
            this.labelDtaInicio.Name = "labelDtaInicio";
            this.labelDtaInicio.Size = new System.Drawing.Size(61, 13);
            this.labelDtaInicio.TabIndex = 133;
            this.labelDtaInicio.Text = "Data Inicio:";
            // 
            // labelTipoServico
            // 
            this.labelTipoServico.AutoSize = true;
            this.labelTipoServico.Location = new System.Drawing.Point(112, 146);
            this.labelTipoServico.Name = "labelTipoServico";
            this.labelTipoServico.Size = new System.Drawing.Size(43, 13);
            this.labelTipoServico.TabIndex = 132;
            this.labelTipoServico.Text = "Estado:";
            // 
            // buttonGuardar
            // 
            this.buttonGuardar.Location = new System.Drawing.Point(335, 268);
            this.buttonGuardar.Name = "buttonGuardar";
            this.buttonGuardar.Size = new System.Drawing.Size(75, 23);
            this.buttonGuardar.TabIndex = 131;
            this.buttonGuardar.Text = "Guardar";
            this.buttonGuardar.UseVisualStyleBackColor = true;
            // 
            // buttonVoltar
            // 
            this.buttonVoltar.Location = new System.Drawing.Point(438, 416);
            this.buttonVoltar.Name = "buttonVoltar";
            this.buttonVoltar.Size = new System.Drawing.Size(75, 23);
            this.buttonVoltar.TabIndex = 130;
            this.buttonVoltar.Text = "Voltar";
            this.buttonVoltar.UseVisualStyleBackColor = true;
            // 
            // textBoxKms
            // 
            this.textBoxKms.Location = new System.Drawing.Point(173, 222);
            this.textBoxKms.Name = "textBoxKms";
            this.textBoxKms.Size = new System.Drawing.Size(218, 20);
            this.textBoxKms.TabIndex = 147;
            // 
            // labelKms
            // 
            this.labelKms.AutoSize = true;
            this.labelKms.Location = new System.Drawing.Point(125, 225);
            this.labelKms.Name = "labelKms";
            this.labelKms.Size = new System.Drawing.Size(30, 13);
            this.labelKms.TabIndex = 146;
            this.labelKms.Text = "Kms:";
            // 
            // Adicionar_Aluguer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 450);
            this.Controls.Add(this.textBoxKms);
            this.Controls.Add(this.labelKms);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxDtaSaida3);
            this.Controls.Add(this.textBoxDtaSaida2);
            this.Controls.Add(this.textBoxDtaSaida1);
            this.Controls.Add(this.textBoxDtaInicio3);
            this.Controls.Add(this.textBoxDtaInicio2);
            this.Controls.Add(this.comboBoxEstado);
            this.Controls.Add(this.textBoxDtaInicio1);
            this.Controls.Add(this.labelDtaFim);
            this.Controls.Add(this.labelDtaInicio);
            this.Controls.Add(this.labelTipoServico);
            this.Controls.Add(this.buttonGuardar);
            this.Controls.Add(this.buttonVoltar);
            this.Name = "Adicionar_Aluguer";
            this.Text = "Adicionar_Aluguer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxDtaSaida3;
        private System.Windows.Forms.TextBox textBoxDtaSaida2;
        private System.Windows.Forms.TextBox textBoxDtaSaida1;
        private System.Windows.Forms.TextBox textBoxDtaInicio3;
        private System.Windows.Forms.TextBox textBoxDtaInicio2;
        private System.Windows.Forms.ComboBox comboBoxEstado;
        private System.Windows.Forms.TextBox textBoxDtaInicio1;
        private System.Windows.Forms.Label labelDtaFim;
        private System.Windows.Forms.Label labelDtaInicio;
        private System.Windows.Forms.Label labelTipoServico;
        private System.Windows.Forms.Button buttonGuardar;
        private System.Windows.Forms.Button buttonVoltar;
        private System.Windows.Forms.TextBox textBoxKms;
        private System.Windows.Forms.Label labelKms;
    }
}