﻿namespace Real_Stand
{
    partial class Pagina_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pagina_Principal));
            this.groupBoxGestaoVendas = new System.Windows.Forms.GroupBox();
            this.pictureBoxGestaoVendas = new System.Windows.Forms.PictureBox();
            this.labelGestaoVendas = new System.Windows.Forms.Label();
            this.groupBoxGestaoAluguer = new System.Windows.Forms.GroupBox();
            this.pictureBoxGestaoAluguer = new System.Windows.Forms.PictureBox();
            this.labelGestaoAluguer = new System.Windows.Forms.Label();
            this.groupBoxGestaoOficina = new System.Windows.Forms.GroupBox();
            this.pictureBoxGestaoOficina = new System.Windows.Forms.PictureBox();
            this.labelGestaoOficina = new System.Windows.Forms.Label();
            this.groupBoxGestaoClientes = new System.Windows.Forms.GroupBox();
            this.pictureBoxGestaoClientes = new System.Windows.Forms.PictureBox();
            this.labelGestaoClientes = new System.Windows.Forms.Label();
            this.labelOpcao = new System.Windows.Forms.Label();
            this.groupBoxGestaoVendas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoVendas)).BeginInit();
            this.groupBoxGestaoAluguer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoAluguer)).BeginInit();
            this.groupBoxGestaoOficina.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoOficina)).BeginInit();
            this.groupBoxGestaoClientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoClientes)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxGestaoVendas
            // 
            this.groupBoxGestaoVendas.Controls.Add(this.pictureBoxGestaoVendas);
            this.groupBoxGestaoVendas.Controls.Add(this.labelGestaoVendas);
            this.groupBoxGestaoVendas.Location = new System.Drawing.Point(536, 154);
            this.groupBoxGestaoVendas.Name = "groupBoxGestaoVendas";
            this.groupBoxGestaoVendas.Size = new System.Drawing.Size(150, 150);
            this.groupBoxGestaoVendas.TabIndex = 14;
            this.groupBoxGestaoVendas.TabStop = false;
            // 
            // pictureBoxGestaoVendas
            // 
            this.pictureBoxGestaoVendas.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGestaoVendas.Image")));
            this.pictureBoxGestaoVendas.Location = new System.Drawing.Point(6, 16);
            this.pictureBoxGestaoVendas.Name = "pictureBoxGestaoVendas";
            this.pictureBoxGestaoVendas.Size = new System.Drawing.Size(138, 128);
            this.pictureBoxGestaoVendas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxGestaoVendas.TabIndex = 1;
            this.pictureBoxGestaoVendas.TabStop = false;
            // 
            // labelGestaoVendas
            // 
            this.labelGestaoVendas.AutoSize = true;
            this.labelGestaoVendas.Location = new System.Drawing.Point(30, 0);
            this.labelGestaoVendas.Name = "labelGestaoVendas";
            this.labelGestaoVendas.Size = new System.Drawing.Size(95, 13);
            this.labelGestaoVendas.TabIndex = 0;
            this.labelGestaoVendas.Text = "Gestão de Vendas";
            // 
            // groupBoxGestaoAluguer
            // 
            this.groupBoxGestaoAluguer.Controls.Add(this.pictureBoxGestaoAluguer);
            this.groupBoxGestaoAluguer.Controls.Add(this.labelGestaoAluguer);
            this.groupBoxGestaoAluguer.Location = new System.Drawing.Point(380, 154);
            this.groupBoxGestaoAluguer.Name = "groupBoxGestaoAluguer";
            this.groupBoxGestaoAluguer.Size = new System.Drawing.Size(150, 150);
            this.groupBoxGestaoAluguer.TabIndex = 13;
            this.groupBoxGestaoAluguer.TabStop = false;
            // 
            // pictureBoxGestaoAluguer
            // 
            this.pictureBoxGestaoAluguer.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGestaoAluguer.Image")));
            this.pictureBoxGestaoAluguer.Location = new System.Drawing.Point(6, 16);
            this.pictureBoxGestaoAluguer.Name = "pictureBoxGestaoAluguer";
            this.pictureBoxGestaoAluguer.Size = new System.Drawing.Size(138, 128);
            this.pictureBoxGestaoAluguer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxGestaoAluguer.TabIndex = 1;
            this.pictureBoxGestaoAluguer.TabStop = false;
            this.pictureBoxGestaoAluguer.Click += new System.EventHandler(this.pictureBoxGestaoAluguer_Click);
            // 
            // labelGestaoAluguer
            // 
            this.labelGestaoAluguer.AutoSize = true;
            this.labelGestaoAluguer.Location = new System.Drawing.Point(30, 0);
            this.labelGestaoAluguer.Name = "labelGestaoAluguer";
            this.labelGestaoAluguer.Size = new System.Drawing.Size(95, 13);
            this.labelGestaoAluguer.TabIndex = 0;
            this.labelGestaoAluguer.Text = "Gestão de Aluguer";
            // 
            // groupBoxGestaoOficina
            // 
            this.groupBoxGestaoOficina.Controls.Add(this.pictureBoxGestaoOficina);
            this.groupBoxGestaoOficina.Controls.Add(this.labelGestaoOficina);
            this.groupBoxGestaoOficina.Location = new System.Drawing.Point(224, 154);
            this.groupBoxGestaoOficina.Name = "groupBoxGestaoOficina";
            this.groupBoxGestaoOficina.Size = new System.Drawing.Size(150, 150);
            this.groupBoxGestaoOficina.TabIndex = 12;
            this.groupBoxGestaoOficina.TabStop = false;
            // 
            // pictureBoxGestaoOficina
            // 
            this.pictureBoxGestaoOficina.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGestaoOficina.Image")));
            this.pictureBoxGestaoOficina.Location = new System.Drawing.Point(6, 16);
            this.pictureBoxGestaoOficina.Name = "pictureBoxGestaoOficina";
            this.pictureBoxGestaoOficina.Size = new System.Drawing.Size(138, 128);
            this.pictureBoxGestaoOficina.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxGestaoOficina.TabIndex = 1;
            this.pictureBoxGestaoOficina.TabStop = false;
            this.pictureBoxGestaoOficina.Click += new System.EventHandler(this.pictureBoxGestaoOficina_Click);
            // 
            // labelGestaoOficina
            // 
            this.labelGestaoOficina.AutoSize = true;
            this.labelGestaoOficina.Location = new System.Drawing.Point(32, 0);
            this.labelGestaoOficina.Name = "labelGestaoOficina";
            this.labelGestaoOficina.Size = new System.Drawing.Size(92, 13);
            this.labelGestaoOficina.TabIndex = 0;
            this.labelGestaoOficina.Text = "Gestão de Oficina";
            // 
            // groupBoxGestaoClientes
            // 
            this.groupBoxGestaoClientes.Controls.Add(this.pictureBoxGestaoClientes);
            this.groupBoxGestaoClientes.Controls.Add(this.labelGestaoClientes);
            this.groupBoxGestaoClientes.Location = new System.Drawing.Point(68, 154);
            this.groupBoxGestaoClientes.Name = "groupBoxGestaoClientes";
            this.groupBoxGestaoClientes.Size = new System.Drawing.Size(150, 150);
            this.groupBoxGestaoClientes.TabIndex = 11;
            this.groupBoxGestaoClientes.TabStop = false;
            // 
            // pictureBoxGestaoClientes
            // 
            this.pictureBoxGestaoClientes.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGestaoClientes.Image")));
            this.pictureBoxGestaoClientes.Location = new System.Drawing.Point(6, 16);
            this.pictureBoxGestaoClientes.Name = "pictureBoxGestaoClientes";
            this.pictureBoxGestaoClientes.Size = new System.Drawing.Size(138, 128);
            this.pictureBoxGestaoClientes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxGestaoClientes.TabIndex = 1;
            this.pictureBoxGestaoClientes.TabStop = false;
            this.pictureBoxGestaoClientes.Click += new System.EventHandler(this.pictureBoxGestaoClientes_Click);
            // 
            // labelGestaoClientes
            // 
            this.labelGestaoClientes.AutoSize = true;
            this.labelGestaoClientes.Location = new System.Drawing.Point(28, 0);
            this.labelGestaoClientes.Name = "labelGestaoClientes";
            this.labelGestaoClientes.Size = new System.Drawing.Size(96, 13);
            this.labelGestaoClientes.TabIndex = 0;
            this.labelGestaoClientes.Text = "Gestão de Clientes";
            // 
            // labelOpcao
            // 
            this.labelOpcao.AutoSize = true;
            this.labelOpcao.Location = new System.Drawing.Point(46, 73);
            this.labelOpcao.Name = "labelOpcao";
            this.labelOpcao.Size = new System.Drawing.Size(107, 13);
            this.labelOpcao.TabIndex = 10;
            this.labelOpcao.Text = "Escolha a sua opção";
            // 
            // Pagina_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBoxGestaoVendas);
            this.Controls.Add(this.groupBoxGestaoAluguer);
            this.Controls.Add(this.groupBoxGestaoOficina);
            this.Controls.Add(this.groupBoxGestaoClientes);
            this.Controls.Add(this.labelOpcao);
            this.Name = "Pagina_Principal";
            this.Text = "Form1";
            this.groupBoxGestaoVendas.ResumeLayout(false);
            this.groupBoxGestaoVendas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoVendas)).EndInit();
            this.groupBoxGestaoAluguer.ResumeLayout(false);
            this.groupBoxGestaoAluguer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoAluguer)).EndInit();
            this.groupBoxGestaoOficina.ResumeLayout(false);
            this.groupBoxGestaoOficina.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoOficina)).EndInit();
            this.groupBoxGestaoClientes.ResumeLayout(false);
            this.groupBoxGestaoClientes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGestaoClientes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxGestaoVendas;
        private System.Windows.Forms.PictureBox pictureBoxGestaoVendas;
        private System.Windows.Forms.Label labelGestaoVendas;
        private System.Windows.Forms.GroupBox groupBoxGestaoAluguer;
        private System.Windows.Forms.PictureBox pictureBoxGestaoAluguer;
        private System.Windows.Forms.Label labelGestaoAluguer;
        private System.Windows.Forms.GroupBox groupBoxGestaoOficina;
        private System.Windows.Forms.PictureBox pictureBoxGestaoOficina;
        private System.Windows.Forms.Label labelGestaoOficina;
        private System.Windows.Forms.GroupBox groupBoxGestaoClientes;
        private System.Windows.Forms.PictureBox pictureBoxGestaoClientes;
        private System.Windows.Forms.Label labelGestaoClientes;
        private System.Windows.Forms.Label labelOpcao;
    }
}

