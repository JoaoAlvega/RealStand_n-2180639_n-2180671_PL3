﻿namespace Real_Stand
{
    partial class Adicionar_Carro_Oficina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelMarca = new System.Windows.Forms.Label();
            this.textBoxMarca = new System.Windows.Forms.TextBox();
            this.labelModelo = new System.Windows.Forms.Label();
            this.labelCombustivel = new System.Windows.Forms.Label();
            this.labelNumChassis = new System.Windows.Forms.Label();
            this.labelMatricula = new System.Windows.Forms.Label();
            this.labelKms = new System.Windows.Forms.Label();
            this.textBoxModelo = new System.Windows.Forms.TextBox();
            this.textBoxNumChassis = new System.Windows.Forms.TextBox();
            this.textBoxMatricula = new System.Windows.Forms.TextBox();
            this.textBoxKms = new System.Windows.Forms.TextBox();
            this.buttonVoltar = new System.Windows.Forms.Button();
            this.buttonGuardar = new System.Windows.Forms.Button();
            this.labelCliente = new System.Windows.Forms.Label();
            this.textBoxMatricula2 = new System.Windows.Forms.TextBox();
            this.textBoxMatricula3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxCombustivel = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // labelMarca
            // 
            this.labelMarca.AutoSize = true;
            this.labelMarca.Location = new System.Drawing.Point(128, 133);
            this.labelMarca.Name = "labelMarca";
            this.labelMarca.Size = new System.Drawing.Size(40, 13);
            this.labelMarca.TabIndex = 0;
            this.labelMarca.Text = "Marca:";
            // 
            // textBoxMarca
            // 
            this.textBoxMarca.Location = new System.Drawing.Point(174, 130);
            this.textBoxMarca.Name = "textBoxMarca";
            this.textBoxMarca.Size = new System.Drawing.Size(218, 20);
            this.textBoxMarca.TabIndex = 1;
            // 
            // labelModelo
            // 
            this.labelModelo.AutoSize = true;
            this.labelModelo.Location = new System.Drawing.Point(123, 159);
            this.labelModelo.Name = "labelModelo";
            this.labelModelo.Size = new System.Drawing.Size(45, 13);
            this.labelModelo.TabIndex = 2;
            this.labelModelo.Text = "Modelo:";
            // 
            // labelCombustivel
            // 
            this.labelCombustivel.AutoSize = true;
            this.labelCombustivel.Location = new System.Drawing.Point(101, 185);
            this.labelCombustivel.Name = "labelCombustivel";
            this.labelCombustivel.Size = new System.Drawing.Size(67, 13);
            this.labelCombustivel.TabIndex = 3;
            this.labelCombustivel.Text = "Combustivel:";
            // 
            // labelNumChassis
            // 
            this.labelNumChassis.AutoSize = true;
            this.labelNumChassis.Location = new System.Drawing.Point(94, 211);
            this.labelNumChassis.Name = "labelNumChassis";
            this.labelNumChassis.Size = new System.Drawing.Size(74, 13);
            this.labelNumChassis.TabIndex = 4;
            this.labelNumChassis.Text = "Num. Chassis:";
            // 
            // labelMatricula
            // 
            this.labelMatricula.AutoSize = true;
            this.labelMatricula.Location = new System.Drawing.Point(115, 237);
            this.labelMatricula.Name = "labelMatricula";
            this.labelMatricula.Size = new System.Drawing.Size(53, 13);
            this.labelMatricula.TabIndex = 5;
            this.labelMatricula.Text = "Matricula:";
            // 
            // labelKms
            // 
            this.labelKms.AutoSize = true;
            this.labelKms.Location = new System.Drawing.Point(133, 263);
            this.labelKms.Name = "labelKms";
            this.labelKms.Size = new System.Drawing.Size(30, 13);
            this.labelKms.TabIndex = 6;
            this.labelKms.Text = "Kms:";
            // 
            // textBoxModelo
            // 
            this.textBoxModelo.Location = new System.Drawing.Point(174, 156);
            this.textBoxModelo.Name = "textBoxModelo";
            this.textBoxModelo.Size = new System.Drawing.Size(218, 20);
            this.textBoxModelo.TabIndex = 7;
            // 
            // textBoxNumChassis
            // 
            this.textBoxNumChassis.Location = new System.Drawing.Point(174, 208);
            this.textBoxNumChassis.Name = "textBoxNumChassis";
            this.textBoxNumChassis.Size = new System.Drawing.Size(218, 20);
            this.textBoxNumChassis.TabIndex = 9;
            // 
            // textBoxMatricula
            // 
            this.textBoxMatricula.Location = new System.Drawing.Point(174, 234);
            this.textBoxMatricula.Name = "textBoxMatricula";
            this.textBoxMatricula.Size = new System.Drawing.Size(35, 20);
            this.textBoxMatricula.TabIndex = 10;
            // 
            // textBoxKms
            // 
            this.textBoxKms.Location = new System.Drawing.Point(174, 260);
            this.textBoxKms.Name = "textBoxKms";
            this.textBoxKms.Size = new System.Drawing.Size(218, 20);
            this.textBoxKms.TabIndex = 11;
            this.textBoxKms.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxKms_KeyPress);
            // 
            // buttonVoltar
            // 
            this.buttonVoltar.Location = new System.Drawing.Point(436, 415);
            this.buttonVoltar.Name = "buttonVoltar";
            this.buttonVoltar.Size = new System.Drawing.Size(75, 23);
            this.buttonVoltar.TabIndex = 108;
            this.buttonVoltar.Text = "Voltar";
            this.buttonVoltar.UseVisualStyleBackColor = true;
            this.buttonVoltar.Click += new System.EventHandler(this.buttonVoltar_Click);
            // 
            // buttonGuardar
            // 
            this.buttonGuardar.Location = new System.Drawing.Point(316, 287);
            this.buttonGuardar.Name = "buttonGuardar";
            this.buttonGuardar.Size = new System.Drawing.Size(75, 23);
            this.buttonGuardar.TabIndex = 109;
            this.buttonGuardar.Text = "Guardar";
            this.buttonGuardar.UseVisualStyleBackColor = true;
            this.buttonGuardar.Click += new System.EventHandler(this.buttonGuardar_Click);
            // 
            // labelCliente
            // 
            this.labelCliente.AutoSize = true;
            this.labelCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCliente.Location = new System.Drawing.Point(168, 98);
            this.labelCliente.Name = "labelCliente";
            this.labelCliente.Size = new System.Drawing.Size(0, 13);
            this.labelCliente.TabIndex = 110;
            // 
            // textBoxMatricula2
            // 
            this.textBoxMatricula2.Location = new System.Drawing.Point(238, 234);
            this.textBoxMatricula2.Name = "textBoxMatricula2";
            this.textBoxMatricula2.Size = new System.Drawing.Size(35, 20);
            this.textBoxMatricula2.TabIndex = 111;
            // 
            // textBoxMatricula3
            // 
            this.textBoxMatricula3.Location = new System.Drawing.Point(301, 234);
            this.textBoxMatricula3.Name = "textBoxMatricula3";
            this.textBoxMatricula3.Size = new System.Drawing.Size(35, 20);
            this.textBoxMatricula3.TabIndex = 112;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(279, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 13);
            this.label1.TabIndex = 113;
            this.label1.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(222, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 114;
            this.label2.Text = "-";
            // 
            // comboBoxCombustivel
            // 
            this.comboBoxCombustivel.FormattingEnabled = true;
            this.comboBoxCombustivel.Items.AddRange(new object[] {
            "GASOLEO",
            "GASOLINA",
            "GPL"});
            this.comboBoxCombustivel.Location = new System.Drawing.Point(175, 183);
            this.comboBoxCombustivel.Name = "comboBoxCombustivel";
            this.comboBoxCombustivel.Size = new System.Drawing.Size(217, 21);
            this.comboBoxCombustivel.TabIndex = 115;
            // 
            // Adicionar_Carro_Oficina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 450);
            this.Controls.Add(this.comboBoxCombustivel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxMatricula3);
            this.Controls.Add(this.textBoxMatricula2);
            this.Controls.Add(this.labelCliente);
            this.Controls.Add(this.buttonGuardar);
            this.Controls.Add(this.buttonVoltar);
            this.Controls.Add(this.textBoxKms);
            this.Controls.Add(this.textBoxMatricula);
            this.Controls.Add(this.textBoxNumChassis);
            this.Controls.Add(this.textBoxModelo);
            this.Controls.Add(this.labelKms);
            this.Controls.Add(this.labelMatricula);
            this.Controls.Add(this.labelNumChassis);
            this.Controls.Add(this.labelCombustivel);
            this.Controls.Add(this.labelModelo);
            this.Controls.Add(this.textBoxMarca);
            this.Controls.Add(this.labelMarca);
            this.Name = "Adicionar_Carro_Oficina";
            this.Text = "Adicionar_Carro_Oficina";
            this.Load += new System.EventHandler(this.Adicionar_Carro_Oficina_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelMarca;
        private System.Windows.Forms.TextBox textBoxMarca;
        private System.Windows.Forms.Label labelModelo;
        private System.Windows.Forms.Label labelCombustivel;
        private System.Windows.Forms.Label labelNumChassis;
        private System.Windows.Forms.Label labelMatricula;
        private System.Windows.Forms.Label labelKms;
        private System.Windows.Forms.TextBox textBoxModelo;
        private System.Windows.Forms.TextBox textBoxNumChassis;
        private System.Windows.Forms.TextBox textBoxMatricula;
        private System.Windows.Forms.TextBox textBoxKms;
        private System.Windows.Forms.Button buttonVoltar;
        private System.Windows.Forms.Button buttonGuardar;
        private System.Windows.Forms.Label labelCliente;
        private System.Windows.Forms.TextBox textBoxMatricula2;
        private System.Windows.Forms.TextBox textBoxMatricula3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxCombustivel;
    }
}